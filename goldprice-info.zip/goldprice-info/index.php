<?php 
// Silence is golden 